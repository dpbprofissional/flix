import { Play, Info } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Hero = () => {
  return (
    <div className="relative h-[80vh] w-full">
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1920&h=1080&fit=crop')",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/50 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
      </div>

      <div className="relative flex h-full items-center px-4 md-12">
        <div className="max-w-2xl space-y-6">
          <h1 className="text-4xl font-bold leading-tight text-foreground md-6xl lg-7xl">
            The Ultimate Streaming Experience
          </h1>
          <p className="text-lg text-foreground/90 md-xl">
            Watch award-winning series, films, documentaries, and more on thousands of devices.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button size="lg" className="bg-primary text-primary-foreground hover-primary/90">
              <Play className="mr-2 h-5 w-5" />
              Play
            </Button>
            <Button size="lg" variant="secondary" className="bg-secondary/80 text-secondary-foreground hover-secondary">
              <Info className="mr-2 h-5 w-5" />
              More Info
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
