import { useState } from "react";
import { Play, Plus, ThumbsUp } from "lucide-react";
import { Button } from "@/components/ui/button";



export const ContentCard = ({ title, image }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="group relative aspect-[2/3] overflow-hidden rounded-sm transition-all duration-300 hover-20 hover-110"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <img
        src={image}
        alt={title}
        className="h-full w-full object-cover transition-transform duration-300"
        loading="lazy"
      />
      
      {isHovered && (
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent opacity-0 transition-opacity duration-300 group-hover-100">
          <div className="absolute bottom-0 left-0 right-0 p-3 space-y-2">
            <h3 className="text-sm font-semibold text-foreground line-clamp-1">{title}</h3>
            <div className="flex items-center gap-1">
              <Button size="icon" className="h-7 w-7 rounded-full bg-primary hover-primary/90">
                <Play className="h-3 w-3 fill-primary-foreground text-primary-foreground" />
              </Button>
              <Button size="icon" variant="ghost" className="h-7 w-7 rounded-full border border-border bg-background/50 hover-foreground">
                <Plus className="h-3 w-3" />
              </Button>
              <Button size="icon" variant="ghost" className="h-7 w-7 rounded-full border border-border bg-background/50 hover-foreground">
                <ThumbsUp className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
