import { ContentCard } from "./ContentCard";





export const ContentRow = ({ title, items }) => {
  return (
    <div className="px-4 md-12">
      <h2 className="mb-4 text-xl font-semibold text-foreground md-2xl">{title}</h2>
      <div className="grid grid-cols-2 gap-2 md-cols-3 lg-cols-6 lg-3">
        {items.map((item) => (
          <ContentCard key={item.id} title={item.title} image={item.image} />
        ))}
      </div>
    </div>
  );
};
