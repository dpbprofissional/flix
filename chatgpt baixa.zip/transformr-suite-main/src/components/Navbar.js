import { useState, useEffect } from "react";
import { Search, Bell, User } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        isScrolled ? "bg-background/95 backdrop-blur-sm" : "bg-gradient-to-b from-background/80 to-transparent"
      }`}
    >
      <div className="flex items-center justify-between px-4 py-4 md-12">
        <div className="flex items-center gap-8">
          <h1 className="text-2xl font-bold text-primary md-3xl">STREAMFLIX</h1>
          <div className="hidden items-center gap-6 md">
            <a href="#" className="text-sm font-medium text-foreground/90 transition-colors hover-foreground">
              Home
            </a>
            <a href="#" className="text-sm font-medium text-foreground/60 transition-colors hover-foreground">
              TV Shows
            </a>
            <a href="#" className="text-sm font-medium text-foreground/60 transition-colors hover-foreground">
              Movies
            </a>
            <a href="#" className="text-sm font-medium text-foreground/60 transition-colors hover-foreground">
              New & Popular
            </a>
            <a href="#" className="text-sm font-medium text-foreground/60 transition-colors hover-foreground">
              My List
            </a>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="text-foreground hover-foreground/80">
            <Search className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-foreground hover-foreground/80">
            <Bell className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-foreground hover-foreground/80">
            <User className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </nav>
  );
};
