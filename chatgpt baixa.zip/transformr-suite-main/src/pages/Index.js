import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { ContentRow } from "@/components/ContentRow";

const Index = () => {
  const trendingContent = [
    { id, title: "Stranger Things", image: "https://images.unsplash.com/photo-1574267432644-f446f16c38ce?w=400&h=600&fit=crop" },
    { id, title: "The Crown", image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop" },
    { id, title: "Wednesday", image: "https://images.unsplash.com/photo-1594908900066-3f47337549d8?w=400&h=600&fit=crop" },
    { id, title: "The Witcher", image: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&h=600&fit=crop" },
    { id, title: "Ozark", image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=400&h=600&fit=crop" },
    { id, title: "Dark", image: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=400&h=600&fit=crop" },
  ];

  const popularContent = [
    { id, title: "Breaking Bad", image: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=400&h=600&fit=crop" },
    { id, title: "Money Heist", image: "https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=400&h=600&fit=crop" },
    { id, title: "Squid Game", image: "https://images.unsplash.com/photo-1594908900066-3f47337549d8?w=400&h=600&fit=crop" },
    { id, title: "Black Mirror", image: "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=400&h=600&fit=crop" },
    { id, title: "Narcos", image: "https://images.unsplash.com/photo-1514306191717-452ec28c7814?w=400&h=600&fit=crop" },
    { id, title: "Peaky Blinders", image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop" },
  ];

  const actionContent = [
    { id, title: "Extraction", image: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=400&h=600&fit=crop" },
    { id, title: "The Gray Man", image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=400&h=600&fit=crop" },
    { id, title: "Red Notice", image: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=400&h=600&fit=crop" },
    { id, title: "6 Underground", image: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&h=600&fit=crop" },
    { id, title: "The Old Guard", image: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=400&h=600&fit=crop" },
    { id, title: "Tyler Rake", image: "https://images.unsplash.com/photo-1574267432644-f446f16c38ce?w=400&h=600&fit=crop" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <div className="relative z-10 -mt-32 space-y-12 pb-20">
        <ContentRow title="Trending Now" items={trendingContent} />
        <ContentRow title="Popular on Netflix" items={popularContent} />
        <ContentRow title="Action & Adventure" items={actionContent} />
      </div>
    </div>
  );
};

export default Index;
